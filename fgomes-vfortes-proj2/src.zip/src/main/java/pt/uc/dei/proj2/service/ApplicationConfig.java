package pt.uc.dei.proj2.service;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/rest")
public class ApplicationConfig extends Application{

}
